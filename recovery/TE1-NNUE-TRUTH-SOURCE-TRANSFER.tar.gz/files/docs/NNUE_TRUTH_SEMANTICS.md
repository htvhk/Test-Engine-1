# NNUE truth: score semantics

The B.1 dataset and targets are side-to-move (STM) relative. The quantized runtime
orders its two feature perspectives as STM then opponent and returns the CP head
without another sign conversion. `te1_eval::evaluate_nnue` supplies the board's
STM, so both NNUE and classical evaluation return positive values for the player
to move. Search consumes that convention directly and negates after every move in
root PVS, negamax, and quiescence. UCI reports the resulting root-STM score.

| Boundary | Producer POV | Consumer / conversion | Evidence |
|---|---|---|---|
| B.1 row to target | STM | clipped CP is retained as STM | `dataset.py` validates FEN STM and consumes STM result/teacher fields |
| Feature encoder | White and Black king-relative views | runtime/training use the same `TE1-K32-RP11-v1` ordering | Python fixture and Rust feature tests |
| NNUE hidden input | two absolute accumulators | `prepare_hidden` orders STM first, opponent second | source trace and Python/Rust quantized parity tests |
| CP head | STM normalized score | inverse `tanh(cp/600)`, no sign change | reference-vector tests |
| `te1_eval` | board STM | passes `board.side_to_move()` unchanged | material-sign sanity tests and UCI probes |
| search / qsearch | node STM | parent uses unary negation | deterministic search tests and source trace |
| UCI score | root STM | no additional color conversion | root search output path |

Legal white-extra-queen and black-extra-queen probes return the expected sign
when the side to move is swapped; balanced positions remain finite. Incremental
state is checked exactly against full refresh by the existing forward/backward
and special-move tests, covering quiet moves, captures, king moves, castling, en
passant, promotions, unmake, and king-bucket refresh transitions.
