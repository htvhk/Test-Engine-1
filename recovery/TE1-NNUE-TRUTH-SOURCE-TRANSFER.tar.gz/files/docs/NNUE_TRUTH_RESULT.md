# Production NNUE truth diagnostic

**Classification: `NETWORK_QUALITY_INVESTIGATION_REQUIRED`.** This is a
non-promotion diagnostic, not an Elo estimate or formal strength gate.

## Frozen experiment

- Source base: `f0ad93ad1940b964c513fc56175c7f907b114be9`.
- Engine SHA-256: `183faeb0622730a8aeca86ad837040eeda149e42967b7e37a61c3b8c93897518`.
- Production network SHA-256: `9cba80ed00f31946b54179d2ed63b4639ef3ba62d1a96ba2bca4fca4fc846974`.
- Opening-suite SHA-256: `888200e51c48d8fe8310d840c7d30f0cc7c0721a8ea61fe9fa91f88be65ffc62`.
- 32 evaluator-blind openings, reversed colors, 250,000 nodes/move, one
  deterministic thread, fresh engine processes for every game.
- Candidate: embedded `k32-w128-h32-crelu`; control: intentional classical.
  Every other normalized UCI option was identical.

## Result and independent verification

The candidate scored **4 wins, 0 draws, 60 losses: 4/64 (6.25%)**. Its color
split was White 4/0/28 and Black 0/0/32. Pair scores were 1.0 for pairs 5, 14,
15, and 32, and 0 for the other 28 pairs. Five-bin counts `(0, .5, 1, 1.5, 2)`
were `(28, 0, 4, 0, 0)`.

Independent journal replay reconstructed all 64 checkmates, candidate colors,
results, points, and pair totals with no disagreement. There were zero illegal
moves, crashes, protocol failures, identity mismatches, abnormal events, or
NNUE fallbacks. The raw append-only journal remains untracked evidence.

## Correctness audit

No runtime or search-interface correctness bug was proven. Training declares
STM targets; the runtime orders the STM accumulator first; both evaluator paths
produce node-STM scores; root PVS, negamax, and qsearch negate after a move.
White/black extra-queen probes changed sign with STM as expected (NNUE roughly
+382/-361 cp; classical +910/-894 cp). Passed-pawn, king-only, and balanced
probes were finite and coherent. Python/quantized Rust parity, scalar/SIMD
parity, and exact incremental/full-refresh special-move tests pass. Attestation
proved the intended binary, embedded network, evaluator role, and zero fallback
in both colors.

## Network-quality hypotheses and cheap preflights

- **Proven:** the accepted 128-wide bytes are dramatically weaker than the
  classical evaluator under this diagnostic, while the observed execution path
  is coherent. Do not proceed to a formal production strength gate.
- **Likely — offline selection mismatch:** development loss selected a seed but
  was explicitly not a playing-strength gate. Before training, correlate saved
  per-seed/component reserve metrics with a small fixed-node match using already
  exported networks.
- **Plausible — objective weighting / teacher-target quality:** CP, WDL, and
  result heads may optimize offline loss without useful move ordering. Before
  training, stratify existing reserve errors by tactical/material/endgame class
  and compare sign accuracy and rank correlation against classical probes.
- **Plausible — capacity or under/over-training:** 128 width or the chosen epoch
  may be inadequate. Before training, compare existing 128/256 and seed
  checkpoints' frozen development curves, calibration, and material-sign
  probes; do not launch a new run until this discriminates the hypotheses.
- **Plausible — data distribution:** the 200K split may underrepresent positions
  decisive for search. Before training, report existing category histograms and
  per-category reserve loss/sign accuracy, with game-group split integrity.
- **Unknown — quantization sensitivity:** current parity proves transport, not
  that quantization preserves float playing behavior. Before training, compare
  float-vs-quantized outputs on a fixed stratified reserve sample and the static
  probe set, including sign flips and rank correlation.

Recommended next milestone: a bounded, read-only network-quality preflight on
existing B.1 artifacts. Do not retrain or tune search until it identifies a
specific falsifiable cause and an approved work card.
