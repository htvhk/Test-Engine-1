import unittest

from nnue_truth import candidate_points, summarize


class ResultOrientationTests(unittest.TestCase):
    def test_candidate_color_orientation(self):
        self.assertEqual([candidate_points(result, "white") for result in ("1-0", "1/2-1/2", "0-1")], [1, .5, 0])
        self.assertEqual([candidate_points(result, "black") for result in ("0-1", "1/2-1/2", "1-0")], [1, .5, 0])

    def test_pair_totals_and_independent_orientation(self):
        cases = [("1-0", "0-1", 2), ("1-0", "1/2-1/2", 1.5),
                 ("1-0", "1-0", 1), ("1/2-1/2", "1/2-1/2", 1),
                 ("0-1", "1/2-1/2", .5), ("0-1", "1-0", 0)]
        records = []
        for index, (white_game, black_game, expected) in enumerate(cases):
            # Independent test oracle: explicit maps, no production helper.
            points = {"1-0": 1, "1/2-1/2": .5, "0-1": 0}[white_game]
            points += {"0-1": 1, "1/2-1/2": .5, "1-0": 0}[black_game]
            self.assertEqual(points, expected)
            records.extend(({"pair_id": str(index), "candidate_points": candidate_points(white_game, "white")},
                            {"pair_id": str(index), "candidate_points": candidate_points(black_game, "black")}))
        self.assertEqual(list(summarize(records)["pair_scores"].values()), [2, 1.5, 1, 1, .5, 0])


if __name__ == "__main__":
    unittest.main()
