#!/usr/bin/env python3
"""Compact, deterministic NNUE-vs-classical diagnostic match harness."""

import argparse
import hashlib
import json
import os
import subprocess
import queue
import threading
import time
from collections import Counter, defaultdict
from pathlib import Path

EXPECTED_NETWORK = "k32-w128-h32-crelu"
NETWORK_SHA256 = "9cba80ed00f31946b54179d2ed63b4639ef3ba62d1a96ba2bca4fca4fc846974"
OPTIONS = {"Hash": "16", "Threads": "1", "Deterministic": "true",
           "MoveOverhead": "30", "UseLMR": "true", "UseSEEPruning": "true"}


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def candidate_points(result, candidate_color):
    if result == "1/2-1/2":
        return 0.5
    return 1.0 if (result == "1-0") == (candidate_color == "white") else 0.0


class Process:
    def __init__(self, command):
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE, text=True, bufsize=1)
        self.lines = queue.Queue()
        self.reader = threading.Thread(target=self._read_stdout, daemon=True)
        self.reader.start()

    def _read_stdout(self):
        for line in self.process.stdout:
            self.lines.put(line.rstrip("\n"))

    def send(self, command):
        self.process.stdin.write(command + "\n")
        self.process.stdin.flush()

    def read_until(self, predicate, timeout=120):
        deadline = time.monotonic() + timeout
        lines = []
        while time.monotonic() < deadline:
            try:
                line = self.lines.get(timeout=min(1, max(0, deadline-time.monotonic())))
            except queue.Empty:
                if self.process.poll() is not None:
                    raise RuntimeError(f"process exited {self.process.returncode}: {self.process.stderr.read()}")
                continue
            lines.append(line)
            if predicate(line):
                return line, lines
        raise TimeoutError(f"timeout waiting for protocol response; last lines={lines[-5:]}")

    def close(self):
        if self.process.poll() is None:
            self.send("quit")
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        return self.process.returncode


class Engine(Process):
    def __init__(self, path, use_nnue):
        super().__init__([str(path)])
        self.send("uci")
        self.read_until(lambda line: line == "uciok")
        for name, value in OPTIONS.items():
            self.send(f"setoption name {name} value {value}")
        self.send("setoption name EvalFile value <embedded>")
        self.send(f"setoption name UseNNUE value {'true' if use_nnue else 'false'}")
        self.send("isready")
        self.read_until(lambda line: line == "readyok")
        self.use_nnue = use_nnue
        self.initial_attestation = self.attest()
        expected = ("nnue", "embedded", EXPECTED_NETWORK) if use_nnue else ("classical", "none", None)
        actual = tuple(self.initial_attestation[key] for key in ("mode", "network_source", "network_name"))
        if actual != expected or self.initial_attestation["fallback_count"] != 0:
            raise RuntimeError(f"evaluator identity mismatch: expected={expected}, actual={self.initial_attestation}")

    def attest(self):
        self.send("te1attest")
        line, _ = self.read_until(lambda value: value.startswith("info string te1attest "))
        return json.loads(line.removeprefix("info string te1attest "))

    def move(self, fen, moves, nodes):
        suffix = " moves " + " ".join(moves) if moves else ""
        self.send(f"position fen {fen}{suffix}")
        self.send(f"go nodes {nodes}")
        line, _ = self.read_until(lambda value: value.startswith("bestmove "), timeout=180)
        move = line.split()[1]
        if move == "(none)":
            raise RuntimeError("engine returned no move in ongoing position")
        return move


class Arbiter(Process):
    def __init__(self, path, fen):
        super().__init__([str(path)])
        self.send("new " + fen)
        state = self.response()
        if not state["ok"] or state["status"] != "ongoing":
            raise RuntimeError(f"invalid opening: {state}")

    def response(self):
        line, _ = self.read_until(lambda _line: True, timeout=10)
        return json.loads(line)

    def play(self, move):
        self.send("play " + move)
        state = self.response()
        if not state["ok"]:
            raise RuntimeError(f"arbiter rejected {move}: {state}")
        return state


def result_from_state(state):
    if state["status"] == "checkmate":
        return "0-1" if state["side_to_move"] == "white" else "1-0"
    if state["status"] in ("stalemate", "draw", "draw_repetition"):
        return "1/2-1/2"
    raise ValueError(f"not terminal: {state}")


def play_game(engine_path, arbiter_path, opening, opening_index, candidate_color,
              nodes, opening_sha, binary_sha, campaign_id):
    candidate = control = arbiter = None
    abnormal = []
    moves = []
    try:
        candidate = Engine(engine_path, True)
        control = Engine(engine_path, False)
        arbiter = Arbiter(arbiter_path, opening)
        state = {"status": "ongoing", "side_to_move": opening.split()[1].replace("w", "white").replace("b", "black")}
        while state["status"] == "ongoing":
            if len(moves) >= 512:
                raise RuntimeError("non-terminal game exceeded 512 plies")
            mover = candidate if state["side_to_move"] == candidate_color else control
            move = mover.move(opening, moves, nodes)
            state = arbiter.play(move)
            moves.append(move)
        result = result_from_state(state)
        final_candidate = candidate.attest()
        final_control = control.attest()
        if final_candidate["fallback_count"] or final_control["fallback_count"]:
            raise RuntimeError("unexpected evaluator fallback")
        return {
            "campaign_id": campaign_id, "opening_index": opening_index, "opening_fen": opening,
            "opening_sha256": opening_sha, "pair_id": f"pair-{opening_index:02d}",
            "game_id": f"pair-{opening_index:02d}-{'A' if candidate_color == 'white' else 'B'}",
            "candidate_color": candidate_color, "binary_sha256": binary_sha,
            "network_sha256": NETWORK_SHA256, "options": OPTIONS | {"EvalFile": "<embedded>"},
            "node_limit": nodes, "moves": moves, "terminal_fen": state["fen"],
            "terminal_reason": state["status"], "result": result,
            "candidate_points": candidate_points(result, candidate_color),
            "candidate_attestation": final_candidate, "control_attestation": final_control,
            "process_exit_states": {"candidate": 0, "control": 0, "arbiter": 0},
            "abnormal_events": abnormal,
        }
    finally:
        for process in (candidate, control, arbiter):
            if process is not None:
                process.close()


def load_journal(path):
    if not path.exists():
        return []
    with path.open() as source:
        return [json.loads(line) for line in source if line.strip()]


def summarize(records):
    points = sum(record["candidate_points"] for record in records)
    outcomes = Counter("win" if p == 1 else "draw" if p == 0.5 else "loss"
                       for p in (record["candidate_points"] for record in records))
    pairs = defaultdict(float)
    for record in records:
        pairs[record["pair_id"]] += record["candidate_points"]
    return {"games": len(records), "pairs": len(pairs), "wins": outcomes["win"],
            "draws": outcomes["draw"], "losses": outcomes["loss"], "points": points,
            "score_percent": 100 * points / len(records) if records else 0,
            "pair_scores": dict(sorted(pairs.items())),
            "five_bin_counts": {str(value): sum(score == value for score in pairs.values())
                                for value in (0, 0.5, 1, 1.5, 2)}}


def verify(records, arbiter_path):
    independently_scored = []
    for record in records:
        arbiter = Arbiter(arbiter_path, record["opening_fen"])
        try:
            state = None
            for move in record["moves"]:
                state = arbiter.play(move)
            if state is None or state["status"] == "ongoing":
                raise RuntimeError(f"non-terminal journal game {record['game_id']}")
            result = result_from_state(state)
            # Intentionally independent orientation logic (does not call candidate_points).
            point = 0.5 if result == "1/2-1/2" else float(
                (result == "1-0" and record["candidate_color"] == "white") or
                (result == "0-1" and record["candidate_color"] == "black"))
            if result != record["result"] or point != record["candidate_points"] or state["fen"] != record["terminal_fen"]:
                raise RuntimeError(f"verifier disagreement in {record['game_id']}")
            independently_scored.append(record | {"candidate_points": point})
        finally:
            arbiter.close()
    return summarize(independently_scored)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", type=Path, default=Path("target/release/te1"))
    parser.add_argument("--arbiter", type=Path, default=Path("target/release/te1-arbiter"))
    parser.add_argument("--openings", type=Path, default=Path("tools/nnue_truth_openings.fen"))
    parser.add_argument("--journal", type=Path, default=Path("nnue-truth-games.jsonl"))
    parser.add_argument("--nodes", type=int, default=250_000)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    records = load_journal(args.journal)
    if args.verify_only:
        print(json.dumps(verify(records, args.arbiter), sort_keys=True))
        return
    openings = [line.strip() for line in args.openings.read_text().splitlines() if line.strip()]
    if len(openings) != 32 or len(set(openings)) != 32 or any(len(fen.split()) != 6 for fen in openings):
        raise SystemExit("opening suite must contain 32 unique six-field FENs")
    opening_sha, binary_sha = sha256(args.openings), sha256(args.engine)
    completed = {record["game_id"] for record in records}
    with args.journal.open("a", buffering=1) as journal:
        for index, opening in enumerate(openings, 1):
            for color, suffix in (("white", "A"), ("black", "B")):
                game_id = f"pair-{index:02d}-{suffix}"
                if game_id in completed:
                    continue
                record = play_game(args.engine, args.arbiter, opening, index, color, args.nodes,
                                   opening_sha, binary_sha, "te1-nnue-truth-v1")
                journal.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
                journal.flush()
                os.fsync(journal.fileno())
                records.append(record)
                print(json.dumps({"completed": game_id, "summary": summarize(records)}, sort_keys=True), flush=True)
    print(json.dumps(verify(records, args.arbiter), sort_keys=True))


if __name__ == "__main__":
    main()
